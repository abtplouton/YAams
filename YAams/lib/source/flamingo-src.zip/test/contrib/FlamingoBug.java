package test.contrib;

import java.awt.Dimension;
import java.awt.Image;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.SwingUtilities;

import org.pushingpixels.flamingo.api.common.icon.ImageWrapperResizableIcon;
import org.pushingpixels.flamingo.api.common.icon.ResizableIcon;
import org.pushingpixels.flamingo.api.ribbon.JRibbonFrame;
import org.pushingpixels.flamingo.api.ribbon.RibbonApplicationMenu;

/**
 * The purpose of this class it to trigger the bug described in issue #80 of the
 * Flamingo bug tracker.
 * 
 * @author Martin Karing
 */
public final class FlamingoBug extends JRibbonFrame {
	/**
	 * The serialization UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor that prepares the test frame to display.
	 */
	@SuppressWarnings("nls")
	public FlamingoBug() {
		getRibbon().setApplicationMenu(new RibbonApplicationMenu());
		setApplicationIcon(getResizableIconFromResource("test/contrib/identity.png"));
		setBounds(100, 100, 500, 300);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	/**
	 * Fetch a icon from the resources.
	 * 
	 * @param resource
	 *            the name of the resources
	 * @return the item load or <code>null</code> in case it did not work
	 */
	public static ResizableIcon getResizableIconFromResource(
			final String resource) {
		Image image;
		try {
			image = ImageIO.read(FlamingoBug.class.getClassLoader()
					.getResource(resource));
		} catch (final IOException e) {
			e.printStackTrace();
			return null;
		}
		final int height = image.getHeight(null);
		final int width = image.getWidth(null);
		final ResizableIcon resizeIcon = ImageWrapperResizableIcon.getIcon(
				image, new Dimension(width, height));
		return resizeIcon;
	}

	/**
	 * Run the Test case.
	 * 
	 * @param args
	 *            the launch arguments
	 */
	public static void main(final String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new FlamingoBug().setVisible(true);
			}
		});
	}
}
