package test.contrib;

import java.awt.Dimension;

import javax.swing.SwingUtilities;

import org.pushingpixels.flamingo.api.common.icon.ResizableIcon;
import org.pushingpixels.flamingo.api.ribbon.JRibbonFrame;
import org.pushingpixels.flamingo.api.ribbon.RibbonApplicationMenu;
import org.pushingpixels.flamingo.api.svg.SvgBatikResizableIcon;

/**
 * The purpose of this class it to trigger the bug described in issue #80 of the
 * Flamingo bug tracker.
 * 
 * @author Martin Karing
 */
public final class FlamingoBugSvg extends JRibbonFrame {
	/**
	 * The serialization UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor that prepares the test frame to display.
	 */
	@SuppressWarnings("nls")
	public FlamingoBugSvg() {
		getRibbon().setApplicationMenu(new RibbonApplicationMenu());
		setApplicationIcon(getResizableIconFromResource("test/contrib/identity.png"));
		setBounds(100, 100, 500, 300);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	/**
	 * Fetch a icon from the resources.
	 * 
	 * @param resource
	 *            the name of the resources
	 * @return the item load or <code>null</code> in case it did not work
	 */
	public static ResizableIcon getResizableIconFromResource(
			final String resource) {
		final ResizableIcon resizeIcon = SvgBatikResizableIcon.getSvgIcon(
				FlamingoBugSvg.class.getClassLoader().getResource(
						"test/svg/edit-paste.svg"), new Dimension(16, 16));
		return resizeIcon;
	}

	/**
	 * Run the Test case.
	 * 
	 * @param args
	 *            the launch arguments
	 */
	public static void main(final String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new FlamingoBugSvg().setVisible(true);
			}
		});
	}
}
